octave plots.m && pdflatex bode.tex && pdflatex bode.tex
