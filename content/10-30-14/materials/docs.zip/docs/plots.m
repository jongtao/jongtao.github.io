clear;
hold off;

function plotter(source_file, gain_file)
	m = csvread(source_file);

	% Frequencies, input V, output V
	x = rot90(m(:, 1));
	vi = rot90(m(:, 2));
	vo = rot90(m(:, 3));
	gain = vo ./ vi;	% compute gain

	% Convert to base 10 log scales
	x = log10(x);
	gain = 20*log10(gain);

	% Fit spline to data
	xx = linspace(min(x), max(x), 100);
	yy = spline(x,gain,xx);

	% Plot
	hold off;
	plot(x, gain, 'o');
	hold on;
	plot(xx,yy);

	xlabel('\LARGE Frequency \(log_{10}(\si{\hertz})\)');
	ylabel('\LARGE Magnitude (\si{\decibel})');
	grid on;

	% Export
	print(gain_file, '-dtex');
end

plotter('overall.csv', 'overall.tex');
