#include "system.h"

#include <avr/io.h>
#include <util/delay.h>

#include <stdint.h>
#include <math.h>

#include "pwm_dac.h"
#include "frequency_counter.h"
#include "segment_display.h"
#include "input.h"


inline void set_RC_osccal(void)
{
	// Enable system clock output.
	// Remember to enable CKOUT Fuse. Disable after calibration
	//PINB |= 0x01;
	//OSCCAL = 0x55; // RC calibration
	OSCCAL = 0x80 | 0x11; // RC calibration
} 



inline void set_sys_prescale(void)
{
	CLKPR = 0x80;
	CLKPR = 0x00; // set prescale to 1
}




/* returns correction in voltage. (add to current voltage)
 */
double freq2volt_control(double measured_freq_Hz, double target_freq_Hz,
	double dt_s)
{
	static double K_p_a = 0.0000009;
	static double K_d_a = 0.0000001;
	static double K_i_a = 0.00000011;
	// use double because of tiny integral term
	
	static double K_p_b = 0.0000005;
	static double K_d_b = 0.0000001;
	static double K_i_b = 0;//0.01;
	
	static double prev_error = 0; // for derivative
	static double integral = 0; // for integral accumulation
	double correction = 0;

	double error = target_freq_Hz - measured_freq_Hz;

	double proportional = error;
	double derivative = (error - prev_error) / dt_s;
	//integral = integral + error * dt_s;
	
	static bw_threshold = 10000/2;

	if(-bw_threshold < error && error < bw_threshold)
	{
		integral = integral + error * dt_s;
		correction = (K_p_a * proportional) + (K_d_a * derivative) +
			(K_i_a * integral);
	}
	else
	{
		integral = 0;
		correction = (K_p_b * proportional) + (K_d_b * derivative);
	}


	prev_error = error;
	return correction;
}



void test_freq_counter(void)
{
	enable_freq_counter();
	volatile static uint8_t current = 0;

	for(;;)
	{
		current = TCNT0;
		print_number((uint16_t)current);
	}
}



void seg_test(void)
{
	static uint8_t index = 0;
	static uint8_t number = 0;

	set_7seg(index, number);

	number++;
	if(number > 9)
	{
		index++;
		number = 0;
	}
	
	if(index > 3)
		index = 0;

	_delay_ms(100);
}



void sweep_test(void)
{
	static float voltage = 0.0;

	set_analog_out(voltage, 3.3, ICR1, &OCR1A);

	if(voltage > 3.3)
		voltage = 0.00;
	else
		voltage += 0.001;

	_delay_ms(3);
}



int main(void)
{
	set_RC_osccal();
	// use crystal
	set_sys_prescale();

	setup_pwm_dac();
	setup_7seg();
	setup_freq_counter();
	setup_buttons();
	sei(); // enable interrupts

	set_analog_out(3.3, 3.3, ICR1, &OCR1A);


	double measured_freq_Hz = 0;
	double target_freq_Hz = 1720000.0;
	double point_voltage = 3.3;

	// If measured frequency is too low, raise meas_trim
	//double meas_trim = 1.0017;
	double meas_trim = 1.00001;

	double avged_freq = 0;

	uint8_t need_measurement = 1;


	for(;;)
	{
		if(need_measurement)
		{
			need_measurement = 0;
			start_freq_counter();
		}


		if(get_gate_status() == GATE_STOPPED)
		{
			get_freq(&measured_freq_Hz, meas_trim);
			//avged_freq = freq_avg(measured_freq_Hz);

			point_voltage += freq2volt_control(measured_freq_Hz, target_freq_Hz,
				GATE_TIME);

			// saturate voltage
			if(point_voltage > 3.3)
				point_voltage = 3.3;
			
			if(point_voltage < 0)
				point_voltage = 0;

			//point_voltage = 3.25;
			set_analog_out(point_voltage, 3.3, ICR1, &OCR1A);

			need_measurement = 1;
		}
			
		if(!need_measurement)
		{
			change_freq(&target_freq_Hz);
			if(target_freq_Hz < 50000)
				target_freq_Hz = 50000;
			if(target_freq_Hz > 1800000)
				target_freq_Hz = 1800000;
			//print_number(round(measured_freq_Hz/1000.0));
			print_number(round(target_freq_Hz/1000.0));
			_delay_ms(10);
		}

		//print_number(target_freq_Hz/1000);

	}
}

