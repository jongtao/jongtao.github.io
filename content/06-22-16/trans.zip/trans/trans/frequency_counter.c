#include "frequency_counter.h"



volatile static uint32_t overflow_count = 0; // extends number of bits in counter
volatile static uint8_t gate_count = 0; // extends gate length
volatile static uint8_t counter_gate_open = GATE_STOPPED; // condition variable for T0 contents



void setup_freq_counter(void)
{
	//PD4 is T0

	// Set up Normal Mode counter, no comparisons
	TCCR0A = 0x00;

	// No clock source. Enable T0 to begin counting. Disable to stop counting.
	TCCR0B = 0x00;

	// Enable overflow interrupt
	TIMSK0 |= (1 << TOIE0);


	// Set up Normal counter, Interrupt on compare A
	TCCR2A = 0x00;

	// No clock source. Set clock source to begin counting. Disable to stop
	// counting.
	TCCR2B = 0x00; 

	// Enable gate overflow interrupt
	TIMSK2 |= (1 << TOIE2);

	// Enable overflow interrupt
}



void start_freq_counter(void)
{
	counter_gate_open = GATE_RUNNING;
	overflow_count = 0;
	gate_count = 1; // gate count begins with 1 (multiples of overflows)

	TCNT0 = 0; // reset main counter
	TCNT2 = 0; // reset gate counter

	TCCR0B |= 0x06; // CS=0x06: falling edge, external clock T0
	TCCR2B |= 0x07; // CS=0x07: Prescaler of 1024
	// REMEMBER TO SET CONSTANT PRESCALE_FACTOR TO MATCH
}



void stop_freq_counter(void)
{
	TCCR0B &= ~(0x07); // Remove clock source, main counter
	TCCR2B &= ~(0x07); // Remove clock source, gate counter
	counter_gate_open = GATE_STOPPED;
}



ISR(TIMER0_OVF_vect)
{
	overflow_count++;
}



ISR(TIMER2_OVF_vect)
{
	if(gate_count == TIMER_MUL)
		stop_freq_counter();
	else
		gate_count++;
}



/*
float count_freq(void)
{
	float frequency_Hz = 0;

	//disable_freq_counter();

	start_freq_counter();

	while(counter_gate_open)
		; // busy wait

	frequency_Hz = (float)( (uint32_t)(overflow_count << 8) | (uint32_t)TCNT0 ) ; // raw count
	frequency_Hz = frequency_Hz / GATE_TIME;

	//_delay_ms(10);
	
	return frequency_Hz;
}
*/


/* retrieves a frequency measurement
 * returns 0 if measurement is not ready
 * returns 1 if measurement is made and frequency_Hz has been written
 */
uint8_t get_freq(double* frequency_Hz, float meas_trim)
{
	if(counter_gate_open == GATE_RUNNING)
		return 0;
	else // counter_gate_open == GATE_STOPPED
	{
		// raw count (8 bit shift to accomodate timer 0 contents)
		*frequency_Hz = (double)( (uint32_t)(overflow_count << 8) | (uint32_t)TCNT0 ) ;

		// process raw count into final frequency
		*frequency_Hz = (*frequency_Hz / GATE_TIME) * meas_trim;
		return 1;
	}
}



uint8_t get_gate_status(void)
{
	return counter_gate_open;
}



#define AVG_LEN 64UL
float freq_avg(float new_value)
{
	static float buffer[AVG_LEN] = {0};
	static uint16_t index = 0;

	uint16_t i;
	float accum;

	buffer[index] = new_value;
	index = (index + 1) % AVG_LEN;

	accum = 0;

	for(i=0; i<AVG_LEN; i++)
		accum += buffer[i];

	return accum / AVG_LEN;
}
