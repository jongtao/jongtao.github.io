#pragma once

#include <avr/io.h>

#define STEP_INTERVAL 1000
#define LARGE_STEP_INTERVAL 10000
#define SKIP_THRESH 0xF

void setup_buttons(void);
inline uint8_t read_button_a(void);
inline uint8_t read_button_b(void);
void change_freq(double* frequency);
