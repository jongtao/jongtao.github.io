#pragma once

#include "system.h"

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#include "segment_display.h"

#define TIMER_MUL 3
#define TIMER_SIZE 256
#define CLOCK 8000000 // 8 MHz
#define PRESCALE_FACTOR 1024

#define GATE_STOPPED 0
#define GATE_RUNNING 1

#define GATE_TIME (double)((double)TIMER_SIZE * (double)TIMER_MUL * \
	(double)PRESCALE_FACTOR / (double)CLOCK)

void setup_freq_counter(void);
inline void start_freq_counter(void);
inline void stop_freq_counter(void);
//float count_freq(void);

inline uint8_t get_freq(double* frequency_Hz, float meas_trim);
inline uint8_t get_gate_status(void);


float freq_avg(float new_value);
