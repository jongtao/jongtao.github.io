#pragma once

#include <avr/io.h>


void setup_pwm_dac(void);

inline void set_analog_out(float voltage, float max_volt,
	volatile uint16_t max_bits, volatile uint16_t* reg);
