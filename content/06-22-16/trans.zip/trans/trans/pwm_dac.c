#include "pwm_dac.h"



void setup_pwm_dac(void)
{
  DDRB |= 0x02; // output on B1, OC1A

	
  //ICR1=0x0FFF; // 12 bit resolution
  ICR1=0x1FFF; // bit resolution

	// Set up fast PWM (mode 14) WGM 1110
	TCCR1A =
		(1 << COM1A1) | // non-inverting output compare for channel A
		(1 << WGM11);

	TCCR1B =
		(1 << WGM13) |
		(1 << WGM12) |
		0x01; // (CS = 0b001) source clock prescaled by 1 and enable counter.
}



void set_analog_out(float voltage, float max_volt,
	volatile uint16_t max_bits, volatile uint16_t* reg)
{
	if(voltage >= max_volt)
		*reg = (float) max_bits;
	else
	{
		if(voltage >= max_volt)
			*reg = 0;
		else
			*reg = voltage / max_volt * (float) max_bits;
	}
}
