#include "input.h"


void setup_buttons(void)
{
	PORTC |= (1 << PORTC4) | (1 << PORTC5); // pullup
}



uint8_t read_button_a(void)
{
	return PINC & (1 << PINC4);
}



uint8_t read_button_b(void)
{
	return PINC & (1 << PINC5);
}



void change_freq(double* frequency)
{
	static uint8_t pressed_a = 0;
	static uint8_t pressed_b = 0;
	static uint32_t counter_a = 0;
	static uint32_t counter_b = 0;


	if(!read_button_a() && counter_a != SKIP_THRESH)
		counter_a++;

	if(!read_button_a() && counter_a == SKIP_THRESH)
	{
		counter_a = 0;
		pressed_a = 1;
		*frequency -= LARGE_STEP_INTERVAL;
	}

	if(!read_button_a() && !pressed_a)
	{
		pressed_a = 1;
		*frequency -= STEP_INTERVAL;
	}
	else
		if(read_button_a())
		{
			pressed_a = 0;
			counter_a = 0;
		}



	if(!read_button_b() && counter_b != SKIP_THRESH)
		counter_b++;

	if(!read_button_b() && counter_b == SKIP_THRESH)
	{
		counter_b = 0;
		pressed_b = 1;
		*frequency += LARGE_STEP_INTERVAL;
	}


	if(!read_button_b() && !pressed_b)
	{
		pressed_b = 1;
		*frequency += STEP_INTERVAL;
	}
	else
		if(read_button_b())
		{
			pressed_b = 0;
			counter_b = 0;
		}
}
