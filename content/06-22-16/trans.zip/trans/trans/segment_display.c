#include "segment_display.h"


void off_7seg(void)
{
	// turn segment selectors off
	PORTB &= ~( (1 << 0) | (1 << 2) | (1 << 3) | (1 << 4) );

	// turn segments off
	PORTB |= 1 << 5;
	PORTD |= (1 << 0) | (1 << 1) | (1 << 2) | (1 << 3) | (1 << 5) | (1 << 6);
}



void setup_7seg(void)
{
	// Set pin modes to output
	DDRB |= (1 << 0) | (1 << 2) | (1 << 3) | (1 << 4); 

	DDRB |= (1 << 5);
	DDRD |= (1 << 0) | (1 << 1) | (1 << 2) | (1 << 3) | (1 << 5) | (1 << 6);


	/*
	// turn segment selectors off
	PORTB &= ~( (1 << 0) | (1 << 2) | (1 << 3) | (1 << 4) );

	// turn segments off
	PORTB |= 1 << 5;
	PORTD |= (1 << 0) | (1 << 1) | (1 << 2) | (1 << 3) | (1 << 5) | (1 << 6);
	*/

	off_7seg();
}



void set_7seg(uint8_t index, int8_t number)
{
	/*
	// turn segment selectors off
	PORTB &= ~( (1 << 0) | (1 << 2) | (1 << 3) | (1 << 4) );

	// turn segments off
	PORTB |= 1 << 5;
	PORTD |= (1 << 0) | (1 << 1) | (1 << 2) | (1 << 3) | (1 << 5) | (1 << 6);
	*/

	off_7seg();

	switch(index) // choose 7seg
	{

		case 0:
			PORTB |= (1 << 0);
			break;
		case 1:
			PORTB |= (1 << 2);
			break;
		case 2:
			PORTB |= (1 << 3);
			break;
		case 3:
			PORTB |= (1 << 4);
			break;
	}

	// set 7seg
	switch(number)
	{
		case -1: // special "no character"
			break;
		case 0:
			PORTB &= ~( (1 << 5) );
			PORTD &= ~( (1 << 0) | (1 << 1) | (1 << 2) | (1 << 3) | (1 << 5) );
			break;
		case 1:
			PORTD &= ~( (1 << 0) | (1 << 1) );
			break;
		case 2:
			PORTB &= ~( (1 << 5) );
			PORTD &= ~( (1 << 0) | (1 << 2) | (1 << 3) | (1 << 6) );
			break;
		case 3:
			PORTB &= ~( (1 << 5) );
			PORTD &= ~( (1 << 0) | (1 << 1) | (1 << 2) | (1 << 6) );
			break;
		case 4:
			PORTD &= ~( (1 << 0) | (1 << 1) | (1 << 5) | (1 << 6) );
			break;
		case 5:
			PORTB &= ~( (1 << 5) );
			PORTD &= ~( (1 << 1) | (1 << 2) | (1 << 5) | (1 << 6) );
			break;
		case 6:
			PORTB &= ~( (1 << 5) );
			PORTD &= ~( (1 << 1) | (1 << 2) | (1 << 3) | (1 << 5) | (1 << 6) );
			break;
		case 7:
			PORTB &= ~( (1 << 5) );
			PORTD &= ~( (1 << 0) | (1 << 1) );
			break;
		case 8:
			PORTB &= ~( (1 << 5) );
			PORTD &= ~( (1 << 0) | (1 << 1) | (1 << 2) | (1 << 3) | (1 << 5) | (1 << 6) );
			break;
		case 9:
			PORTB &= ~( (1 << 5) );
			PORTD &= ~( (1 << 0) | (1 << 1) | (1 << 2) | (1 << 5) | (1 << 6) );
			break;
	}
	
}




/* Prints 4 digit number to 7 segment display
 * This function will leave the segments on
 */
void print_number(uint16_t number)
{
	uint16_t tmp_number = number;

	set_7seg(3, number % 10); // 1s
	_delay_us(DIGIT_DELAY_US);

	if(tmp_number >= 10)
	{
		number /= 10;
		set_7seg(2, number % 10); // 10s
		_delay_us(DIGIT_DELAY_US);

		if(tmp_number >= 100)
		{
				number /= 10;
			set_7seg(1, number % 10); // 100s
			_delay_us(DIGIT_DELAY_US);


			if(tmp_number >= 1000)
			{
				number /= 10;
				set_7seg(0, number % 10); // 100s
				_delay_us(DIGIT_DELAY_US);
			} // 1000
		} // 100
	} // 10

	off_7seg();

}
