#pragma once

#define DIGIT_DELAY_US 1000

#include "system.h"

#include <avr/io.h>
#include <util/delay.h>


inline void off_7seg(void);
void setup_7seg(void);
inline void set_7seg(uint8_t index, int8_t number);
void print_number(uint16_t number);
